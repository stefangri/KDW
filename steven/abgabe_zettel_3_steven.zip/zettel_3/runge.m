function [wert]= runge(x) %Defintion der Rungefunktion
  wert=1./(1+25.*x.^2);
end
